$('body').weather({
    key: '27f131f2c97c8d5c768c6048f309814'
});