$.fn.weather = function (options) {
    var params = $.extend({
        key: ''
    }, options);

    if (params.key.length == 0) $('.input').find('h3').html("You've forgotten to write you <a href='https://home.openweathermap.org/api_keys'>API key</a>").css('color', 'red');

    var $card = $('.card');
    var $result = $card.find('.result');

    $('.search').click(function () {
        var city = $card.find('input[name=city]').val();

        if (city.length == 0) $('.input').find('h3').html('Enter the city!');

        $.getJSON('https://api.openweathermap.org/data/2.5/forecast?q=' + city + '&appid=' + params.key + 'c&units=metric')
            .done(function (result) {
                updateData(result);
            })
            .fail(function (error) {
                console.error(error.responseJSON['cod'] + ' ' + error.responseJSON['message']);
                if (error.responseJSON['cod'] == 404) $('.input').find('h3').html("There isn't such city!");
            });
    });

    function updateData(data) {
        var weather = "data['list'][0]['weather']";
        $card.addClass('active');
        $result.html('<h3>' + data['city']['name'] + '</h3>');
        $result.append('<h1>' + data['list'][0]['main']['temp'] + '°<span></span></h1>');
        $result.append('<p class="desc">' + data['list'][0]['weather'][0]['main'] + '</p>');

        $result.find('h1').hover(
            function () {
                $result.find('h1').html('Humidity: ' + data['list'][0]['main']['humidity'] + '%<br>' +
                    'Pressure: ' + data['list'][0]['main']['pressure'] + '<br>' +
                    'Wind speed: ' + data['list'][0]['wind']['speed'] + '<span></span>').css('font-size', '12px');
            },
            function () {
                $result.find('h1').html(data['list'][0]['main']['temp'] + '°<span></span>').css('font-size', '36px');
            });
        day(data);
    }

    function day(data) {
        var temp = [];
        var img = [];
        var nowDay = new Date().getDate();
        var nowMonth = new Date().getMonth();
        var nowYear = new Date().getFullYear();

        $result.append('<ul></ul>')

        for (i = 0; i < data['cnt']; i++) {
            var date = data['list'][i]['dt_txt'];

            if (date.includes('12:00:00')) {
                temp.push(data['list'][i]['main']['temp']);
                img.push(data['list'][i]['weather'][0]['icon']);
            }
        }

        for (i = 0; i < temp.length; i++) {
            var nowDay = new Date().getDate() + 1 + i;
            var nowStringDate = new Date(nowYear, nowMonth, nowDay).toDateString().split(' ', 2);
            $result.find('ul').append('<li>' + nowStringDate[0] + '<p class="feature"><img src="https://openweathermap.org/img/wn/' + img[i] + '@2x.png" width="25">' + temp[i] + '&deg;</p><span></span></li>')
        }

    }
};
